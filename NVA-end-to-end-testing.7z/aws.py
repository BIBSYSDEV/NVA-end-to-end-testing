def main():
    aws = open("../../Users/en/.aws/credentials", "r")
    if aws.mode == "r":
        lines = aws.readlines()
        for line in lines:
            if line.startswith("region"):
                print(line.replace("region = ", "$env:CYPRESS_AWS_REGION="), end='')
            if line.startswith("aws_access_key_id"):
                print(line.replace("aws_access_key_id = ", "$env:CYPRESS_AWS_ACCESS_KEY_ID="), end='')
            if line.startswith("aws_secret_access_key"):
                print(line.replace("aws_secret_access_key = ", "$env:CYPRESS_AWS_SECRET_ACCESS_KEY="), end='')
            if line.startswith("aws_session_token"):
                print(line.replace("aws_session_token = ", "$env:CYPRESS_AWS_SESSION_TOKEN="), end='')
    cognito = open("./cognito.txt", "r")
    if cognito.mode == "r":
        lines = cognito.readlines()
        for line in lines:
            print(line, end='')

main()
